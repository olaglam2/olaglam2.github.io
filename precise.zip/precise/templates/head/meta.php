<?php
/**
 * The template for displaying the header meta
 *
 *
 * @package WordPress
 * @subpackage Theme_Name
 * @since Theme_Version 1.0
 */

do_action('precise/action/head');