<?php
/*
 * Template loop-end
 */
global $precise_member_loop_index, $precise_loop;
$precise_member_loop_index = '';
$loop_style = isset($precise_loop['loop_style']) ? $precise_loop['loop_style'] : 1;
?>
</div>
<!-- .team-member-loop -->
