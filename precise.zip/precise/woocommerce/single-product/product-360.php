<div class="la-threesixty-container">
    <div class="la-threesixty threesixty">
        <div class="spinner"><span>0%</span></div>
        <ol class="threesixty_images"></ol>
    </div>
</div>